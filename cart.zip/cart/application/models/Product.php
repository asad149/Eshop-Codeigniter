<?php 

class Product extends CI_Model
{

	function __construct()
	{
		$this->proTable='products';
		$this->custTable='customers';
		$this->ordTable='orders';
		$this->oreItemsTable='order_items';
	}

	public function getRows($id='')
	{
		$this->db->select('*');
		$this->db->from($this->proTable);
		$this->db->where('status','1');
		if($id)
		{
			$this->db->where('id',$id);
			$query=$this->db->get();
			$result=$query->row_array();
		}
		else
		{
			$this->db->order_by('name','asc');
			$query=$this->db->get();
			$result=$query->result_array();
		
		}
        return !empty($result)?$result:false;
            //return $result;


	}
}

?>