<!DOCTYPE html>
<html>
<head>
	<title></title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
  
  function updateCartItem(obj,rowid)
  {
  	$.get("<?php echo base_url('cart/update/'); ?>",{rowid:rowid,qty:obj.value},function(resp)
  	{
  		if(resp=='ok')
  		{
  			location.reload();
  		}
  		else
  		{
  			alert('Cart update Failed');
  		}
  	});
  }



</script>
</head>
<body>
<div class="container" style="margin-top: 50px">

	<div class="row">

		<h1>Shopping Cart</h1>
		<table class="table">
  <thead class="thead-light">
    <tr>
      <th>#</th>
      <th >Name</th>
      <th >Price</th>
      <th >Quantity</th>
      <th >Sub Total</th>
      <th>Delete</th>
    </tr>
  </thead>
  <tbody>
  	<?php if($this->cart->total_items()>0): ?>
  		<?php foreach($cartItems as $item): ?>
    <tr>
      <th scope="row"><?= $item['id']; ?></th>
      <td><?= $item['name']; ?></td>
      <td><?= '$'.$item['price'].'USD'; ?></td>
      <td><input type="number" class="form-control text-center" value="<?php echo $item["qty"] ?>" onchange="updateCartItem(this,'<?php echo $item["rowid"]; ?>')" name=""></td>
      <td><?php echo '$'.$item["subtotal"].'USD'; ?></td>
      <td>
      	<a href="<?php echo base_url('cart/removeItem/'.$item["rowid"]); ?>" 
      		class="btn btn-danger" onclick="return confirm('Are you sure?')"><i class="glyphicon glyphicon-trash"></i></a>
      </td>
    </tr> 
<?php endforeach; ?>
<?php endif; ?>
  </tbody>

		<tfoot>
			<tr>
	<td><a href="<?php echo base_url('products') ?>"
	class="btn btn-warning"><b><</b> Continue Shopping</a></td>
	<?php if($this->cart->total_items()>0): ?>
        <td><h5 style="font-weight: bold; float: right;" class="text-right">Grand Total: <?php echo '$'.$this->cart->total().'USD'; ?></h5></td>
<?php endif; ?>
<td><a href="<?php echo base_url('checkout/'); ?>" style="float: right;" class="btn btn-success">Check Out</a></td>
</tr>
</tfoot>

</table>

	</div>
	<table>

</table>
</div>

</body>
</html>