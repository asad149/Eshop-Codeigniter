<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>


<div class="container" style="margin-top: 20px">
  <div class="page-heading"><h1 class="text-center">Products</h1></div>
	<a style=" font-size: 20px; float:right;"href="<?php echo base_url('cart'); ?>"
		class="cart-link" title="View Cart">
			<i  class="glyphicon glyphicon-shopping-cart"></i>
			<span>(<?php echo $this->cart->total_items(); ?>)</span>
		</a>
<div class="row ">
		<?php if(count($products)): ?>

		<?php foreach ($products as $prod): ?>
    
      
  <div class="col-md-3">
<div class="card text-center mb-5">
  <h3 class="card-header" style=""><?php echo $prod['name']; ?></h3>
  <div class="card-body">
  
  <img class="img-responsive card-img-top" style="height: 200px; width: 100%; display: block;" src="<?php echo $prod['image']; ?>" alt="Card image">
    <h4>Price: <?= $prod['price']; ?></h4s>
  </div>
  <div class="card-footer" style="width: 200px; margin:auto; margin-bottom: 20px">
<a href="<?php echo base_url('Products/addToCart/'.$prod['id']); ?>" style="font-weight: bold;" class="btn btn-success">Add To Cart</a>
  </div>
  </div>

</div>
 

	<?php endforeach; ?>
		
	<?php else: ?>
		<tr>
		<td colspan="3">No data available</td>
	</tr>
 
	<?php endif; ?>
</div>


</div>

              
	
</body>
</html>