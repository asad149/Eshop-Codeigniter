<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
	<h2>Order Preview</h2>

	<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Price</th>
      <th scope="col">Quantity</th>
      <th scope="col">Sub Total</th>
      
    </tr>
  </thead>
  <tbody>
   
    	<?php if($this->cart->total_items()>0): ?>
    		<?php foreach($cartItems as $item): ?>
    			 <tr>
      <th scope="row"><?= $item['id']  ?></th>
      <td><?= $item['name'] ?></td>
      <td><?= $item['price'] ?></td>
      <td><?= $item['qty'] ?></td>
      <td><?= $item['subtotal'] ?></td>
      </tr>
  <?php endforeach; ?>
  <?php endif; ?>
    
  
  </tbody>
  <tr>
  	<td>
  		<?php if($this->cart->total_items()>0): ?>
  <h4 style="font-weight: bold;">Grand Total: <?= $this->cart->total(); ?></h4>
<?php endif; ?>
</td>
</tr>
</table>

<form class="form-horizontal" method="post">
	<div class="ship-info">
		<h4>Shipping Info</h4>
		<label class="control-label col-sm-2">Name:</label>
		<div class="col-sm-10">
			<input type="text" name="name" class="form-control" value="<?php echo !empty($custData['name'])?$custData['name']:''; ?>" placeholder="Enter Name">
		</div>
	</div>
</div>
</body>
</html>