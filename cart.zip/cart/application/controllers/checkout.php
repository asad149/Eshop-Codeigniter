<?php 

class Checkout extends CI_Controller
{

	function __construct()
	{
		parent::__construct();

		$this->load->library('form_validation');
		$this->load->helper('form');

		$this->load->library('cart');

		$this->load->model('product');

		$this->controller='checkout';
	}
	public function index()
	{
         if($this->cart->total_items()<=0)
         {
         	redirect('products/');
         }

         $custData=$data=array();

         $submit=$this->input->post('placeOrder');

         if(isset($submit))
         {
         	$this->form_validation->set_rules('name','Name','required');

         	$this->form_validation->set_rules('email','Email','required|valid_email');

         	$this->form_validation->set_rules('phone','Phone','required');

         	$this->form_validation->set_rules('address','Address','required');
         }


         $data['custData']=$custData;

         $data['cartItems']=$this->cart->contents();
         $this->load->view($this->controller.'/index',$data);
	} 
}



?>