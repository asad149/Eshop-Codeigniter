<?php

class Products extends CI_Controller
{

   function __construct()
   {
   	parent::__construct();

   	$this->load->library('cart');

   	$this->load->model('product');
   }

	public function index()
	{
		
		$data['products']=$this->product->getRows();

		$this->load->view('products/index',$data);
	}

	public function addToCart($proID)
	{
		$product=$this->product->getRows($proID);
        
        $data=array(
        'id'=>$product['id'],
        'name'=>$product['name'],
        'price'=>$product['price'],
        'qty'=>1
            );

        $this->cart->insert($data);

        redirect('cart/');
	}
}


 ?>